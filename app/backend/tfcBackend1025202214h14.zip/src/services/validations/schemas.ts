import * as Joi from 'joi';

const credentialsSchema = Joi.object({
  email: Joi.string()
    .email()
    .required()
    .label('All fields must be filled'),
  // .messages({
  //   'string.required': 'All fields must be filled',
  // }),

  password: Joi.string()
    .min(6)
    .required()
    .label('All fields must be filled'),
  // .messages({
  //   'string.required': 'All fields must be filled',
  // }),
});

export default credentialsSchema;
